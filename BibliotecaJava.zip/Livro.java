
import java.io.Serializable;


public class Livro extends Acervo implements Serializable{

	private String editora;
	private double ISBN;
	private int edicao;
	private int total;
	private int disponivel;
	public String getEditora() {
		return editora;
	}
	public void setEditora(String editora) {
		this.editora = editora;
	}
	public double getISBN() {
		return ISBN;
	}
	public void setISBN(double iSBN) {
		ISBN = iSBN;
	}
	public int getEdicao() {
		return edicao;
	}
	public void setEdicao(int edicao) {
		this.edicao = edicao;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getDisponivel() {
		return disponivel;
	}
	public void setDisponivel(int disponivel) {
		this.disponivel = disponivel;
	}
	public Livro(String titulo, String idioma, String area_conhecimento, String ano_publicacao, String autor,
			String editora, double iSBN, int edicao, int total, int disponivel) {
		super(titulo, idioma, area_conhecimento, ano_publicacao, autor);
		this.editora = editora;
		ISBN = iSBN;
		this.edicao = edicao;
		this.total = total;
		this.disponivel = disponivel;
	}
	@Override
	public String toString() {
		return " editora = " + editora + "\n" +" ISBN = " + ISBN +"\n" + " edicao = " + edicao + "\n" +" total = " + total
				+ "\n" +" disponivel = " + disponivel + "\n" +" titulo = " + titulo + "\n" +" idioma = " + idioma + "\n" +" área do conhecimento="
				+ area_conhecimento + "\n" +" ano de publicação = " + ano_publicacao +"\n" + " autor =" + autor + "\n";
	}
	
	
	
}