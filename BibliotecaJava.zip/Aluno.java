
import java.io.Serializable;


public class Aluno extends Pessoa implements Serializable {
	private String matricula;
	private String curso;
	private int situacao = 0;
	private int livros_emprestados = 0;
	private String nome_livro1 = null;
	private double ISBN1 = 0;
	private String nome_livro2 = null;
	private double ISBN2 = 0;
	private String nome_livro3 = null;
	private double ISBN3 = 0;
	
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public int getSituacao() {
		return situacao;
	}
	public void setSituacao(int situacao) {
		this.situacao = situacao;
	}
	public int getLivros_emprestados() {
		return livros_emprestados;
	}
	public void setLivros_emprestados(int livros_emprestados) {
		this.livros_emprestados = livros_emprestados;
	}
	public String getNome_livro1() {
		return nome_livro1;
	}
	public void setNome_livro1(String nome_livro1) {
		this.nome_livro1 = nome_livro1;
	}
	public double getISBN1() {
		return ISBN1;
	}
	public void setISBN1(double iSBN1) {
		ISBN1 = iSBN1;
	}
	public String getNome_livro2() {
		return nome_livro2;
	}
	public void setNome_livro2(String nome_livro2) {
		this.nome_livro2 = nome_livro2;
	}
	public double getISBN2() {
		return ISBN2;
	}
	public void setISBN2(double iSBN2) {
		ISBN2 = iSBN2;
	}
	public String getNome_livro3() {
		return nome_livro3;
	}
	public void setNome_livro3(String nome_livro3) {
		this.nome_livro3 = nome_livro3;
	}
	public double getISBN3() {
		return ISBN3;
	}
	public void setISBN3(double iSBN3) {
		ISBN3 = iSBN3;
	}
	public Aluno(String nome, String cPF, String endereco, String telefone, String email, String matricula,
			String curso) {
		super(nome, cPF, endereco, telefone, email);
		this.matricula = matricula;
		this.curso = curso;
	}
	@Override
	public String toString() {
		return super.toString() + " matricula = " + matricula + "\n" +" curso = " + curso + "\n" +" situacao = " + situacao +"\n" + " livros emprestados = "
				+ livros_emprestados + "\n" +" nome do livro 1 = " + nome_livro1 + "\n" +" nome do livro 2 = "
				+ nome_livro2 + "\n"  +" nome do livro 3=" + nome_livro3 +"\n";
	}
        
      


}