import java.util.Calendar;
//import java.time.format.DateTimeFormatter;
//import java.time.LocalTime;
public class Emprestimo {
	//private Data data_emprestimo;
	//private Data data_devolucao;
	private String matricula_bibliotecario;
	private String matricula;
	private String titulo;
	private Calendar data_entrega;
	private Calendar data_emprestimo;
	
    public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	//private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd"); 
    //private LocalDateTime currentTime = LocalDateTime.now(); // Cria o objeto
    //LocalDate data_emprestimo = currentTime.toLocalDate(); // Pega a data atual
	//LocalDate data_entrega;
    
	public Emprestimo(String matricula_bibliotecario, String matricula, String titulo,Calendar data_emprestimo) {
		super();
		this.matricula_bibliotecario = matricula_bibliotecario;
		this.matricula = matricula;
		this.titulo = titulo;
		this.data_emprestimo = (Calendar) data_emprestimo.clone();
		data_entrega = (Calendar) data_emprestimo.clone();
		data_entrega.add(Calendar.DAY_OF_MONTH,14); // Dias que se pode ficar com o livro

	}


	@Override
	public String toString() {
		return "Emprestimo [matricula_bibliotecario=" + matricula_bibliotecario + "\n" +", matricula=" + matricula 
				+ "\n" + ", titulo=" + titulo + "\n" + ", data_entrega=" + data_entrega + "\n" + ", data_emprestimo=" + data_emprestimo
				+ "]\n";
	}


	public Calendar getData_emprestimo() {
		return data_emprestimo;
	}

	public void setData_emprestimo(Calendar data_emprestimo) {
		this.data_emprestimo = data_emprestimo;
	}

	public Calendar getDataEntrega() {
		return data_entrega;
	}

	public void setDataEntrega(Calendar data_entrega) {
		this.data_entrega = data_entrega;
	}

	public String getMatricula_bibliotecario() {
		return matricula_bibliotecario;
	}

	public void setMatricula_bibliotecario(String matricula_bibliotecario) {
		this.matricula_bibliotecario = matricula_bibliotecario;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}





	

	
	

}