import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
public class Bibliotecario extends Pessoa implements Serializable {
    private String matricula;
    private String Login;
    private String senha;
    public String getLogin() {
            return Login;
    }

    public void setLogin(String login) {
            Login = login;
    }

    public String getSenha() {
            return senha;
    }

    public void setSenha(String senha) {
            this.senha = senha;
    }

    public Bibliotecario(String nome, String cPF, String endereco, String telefone, String email, String matricula,
                    String login, String senha) {
            super(nome, cPF, endereco, telefone, email);
            this.matricula = matricula;
            Login = login;
            this.senha = senha;
    }

    public String getMatricula() {
            return matricula;
    }

    public void setMatricula(String matricula) {
            this.matricula = matricula;
    }

    public boolean cadastraLivro(ArrayList<Livro> livro,String titulo,String idioma,String area,String publicacao,String autor,String editora,int edicao,double ISBN,int total){
        Livro l;
        int k = Main.verificaCadastroL(livro,titulo);
        if(k == -1){
            l = new Livro (titulo, idioma, area,publicacao,autor,editora,ISBN,edicao,total,total);
            livro.add(l);
            return true;
        }else{
            return false;
        }
    }



    public String removeProfessor(ArrayList<Professor> professor, String matricula){
            if(professor.isEmpty()){
                    return ("Não há professores cadastrados");
            }
            int k = Main.verificaCadastroP(professor,matricula);
            if(k != -1){
                    if(professor.get(k).getLivros_emprestados() != 0){
                        return ("Este professor não pode ser deletado do sistema pois há pendencias no seu nome");
                    }else{
                        professor.remove(k);
                        return("O professor foi excluído com sucesso");
                    }

            }else{
                    return ("Não há profesor com esta matrícula registrado");
            }

    }
    public String  removeBibliotecario(ArrayList<Bibliotecario> bibliotecario, String matricula){

            if(bibliotecario.isEmpty()){
                    return ("Não há bibliotecarios cadastrados");
            }
            int k = Main.verificaCadastroB(bibliotecario,matricula);
            if(k != -1 ){
                bibliotecario.remove(k);
                return ("O bibliotecario " + bibliotecario.get(k).toString()+ "foi excluído com sucesso");
            }else{
                return ("Não há bibliotecário com esta matrícula registrado");

            }
    }
public String recebeLivroAluno(ArrayList<Emprestimo> emprestimo,ArrayList<Livro> livro,ArrayList<Aluno> aluno, Calendar dataAtual,String titulo, String matricula){
      //  LocalDateTime currentTime = LocalDateTime.now(); // Cria o objeto
            int k = Main.verificaCadastroL(livro,titulo);
            if(k != -1){
                    int auxA = Main.verificaCadastroA(aluno,matricula);
                    if(auxA != -1){
                            int aux = Main.verificaEmprestimo(emprestimo,matricula,titulo);
                            if(aux != -1){
                                    aluno.get(auxA).setLivros_emprestados(aluno.get(auxA).getLivros_emprestados() - 1);
                                    if(aluno.get(auxA).getLivros_emprestados() + 1 >= 1){
                                            if(aluno.get(auxA).getNome_livro1().equals(titulo)){
                                                    aluno.get(auxA).setNome_livro1("");
                                                    aluno.get(auxA).setISBN1(0);
                                                    livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                            }else if(aluno.get(auxA).getNome_livro2().equals(titulo)){
                                                    aluno.get(auxA).setNome_livro2("");
                                                    aluno.get(auxA).setISBN2(0);
                                                    livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                            }else{
                                                    aluno.get(auxA).setNome_livro3("");
                                                    aluno.get(auxA).setISBN3(0);
                                                    livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                            }
                                    }
                                            if(dataAtual.after(emprestimo.get(aux).getDataEntrega())){ // Pega o dia da data atual
                                                    long u = getDifferenceDays(dataAtual,emprestimo.get(aux).getDataEntrega()); 
                                                    aluno.get(auxA).setSituacao((int) (Math.abs(u) * 2));
                                                    emprestimo.remove(aux);
                                                    return ("Este aluno atrasou o prazo de entrega,e teré punição de " + Math.abs(u) + " dias");

                                            }else{
                                                    return ("O livro foi devolvido com sucesso");

                                            }
                            }else{
                                    return ("Este aluno não pegou este livro emprestado");
                            }
                    }else{
                            return ("Este aluno não está registrado na biblioteca");
                    }
            }else{
                    return ("Este livro não está registrado");
            }
    }

public String recebeLivroProfessor(ArrayList<Emprestimo> emprestimo,ArrayList<Livro> livro,ArrayList<Professor> professor, Calendar dataAtual, String titulo, String matricula){
//  LocalDateTime currentTime = LocalDateTime.now(); // Cria o objeto
    int k = Main.verificaCadastroL(livro,titulo);
    if(k != -1){
            int auxA = Main.verificaCadastroP(professor,matricula);
            if(auxA != -1){
                    int aux = Main.verificaEmprestimo(emprestimo,matricula,titulo);
                    if(aux != -1){
                            professor.get(auxA).setLivros_emprestados(professor.get(auxA).getLivros_emprestados() - 1);
                            if(professor.get(auxA).getLivros_emprestados() + 1 >= 1){
                                    if(professor.get(auxA).getNome_livro1().equals(titulo)){
                                            professor.get(auxA).setNome_livro1("");
                                            professor.get(auxA).setISBN1(0);
                                            livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                    }else if(professor.get(auxA).getNome_livro2().equals(titulo)){
                                            professor.get(auxA).setNome_livro2("");
                                            professor.get(auxA).setISBN2(0);
                                            livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                    }else{
                                            professor.get(auxA).setNome_livro3("");
                                            professor.get(auxA).setISBN3(0);
                                            livro.get(k).setDisponivel(livro.get(k).getDisponivel() + 1);

                                    }
                            }
                                    if(dataAtual.after(emprestimo.get(aux).getDataEntrega())){ // Pega o dia da data atual
                                            long u = getDifferenceDays(dataAtual,emprestimo.get(aux).getDataEntrega()); 
                                            professor.get(auxA).setSituacao((int)Math.abs(u)); 
                                            emprestimo.remove(aux);
                                            return ("Este professor atrasou o prazo de entrega,e terá punição de " + Math.abs(u) + " dias");

                                    }else{
                                            return ("O livro foi devolvido com sucesso");

                                    }
                    }else{
                            return ("Este professor não pegou este livro emprestado");
                    }
            }else{
                    return ("Este professor não está registrado na biblioteca");
            }
    }else{
            return ("Este livro não está registrado");
    }
}


    public boolean cadastraAluno(ArrayList<Aluno> aluno, Aluno a){
        int k = Main.verificaCadastroA(aluno, a.getMatricula());
        if(k == -1){
            aluno.add(a);
            return true;
        }else{
            return false;

        }
    }
    public boolean cadastraPeriodico(ArrayList<Periodico> periodico,String titulo, String idioma, String area_conhecimento,String ano_publicacao,String autor,double ISSN,int total){
            Periodico p;
          int k = Main.verificaCadastroPeriodico(periodico,titulo);
          if(k == -1){
            p = new Periodico(titulo, idioma, area_conhecimento,ano_publicacao,autor,ISSN,total);
            periodico.add(p);
            return true;
          }else{
              return false;
          }
    }

    public String removePeriodico(ArrayList<Periodico> periodico, String titulo){
            int i;
            for(i = 0; i < periodico.size(); i++){
                    if(periodico.get(i).getTitulo().equals(titulo)){
                    periodico.remove(i);
                    i = 0;
                    return ("Periódico removido com sucesso");
                    }
            }
            if(i == 0){
                    return ("Periódico não registrado");
            }else{
                    return ("Periódico removido com sucesso");
            }
    }
    @Override
    public String toString() {
            return "matrícula = " + matricula +"\n" + " Login = " + Login  +"\n" 
                            + " nome = " + nome +"\n" + " CPF = " + CPF + "\n" +" endereço = " + endereco + "\n" +" telefone = " + telefone + "\n" +" email = "
                            + email + "\n";
    }

    public String removeAluno(ArrayList<Aluno> aluno,String matricula){
            if(aluno.isEmpty()){
                    return ("Não há alunos cadastrados");
            }
            int k = Main.verificaCadastroA(aluno,matricula);
            if( k != -1){
                    if(aluno.get(k).getLivros_emprestados() != 0){
                            return ("Este aluno não pode ser deletado do sistema pois há pendencias no seu nome");
                    }else{
                        aluno.remove(k);
                        return ("O aluno foi excluído com sucesso");
                    }
            }else{
                    return ("Não há aluno com esta matrícula registrado");

            }
    }

    public static long getDifferenceDays(Calendar d1, Calendar d2) {
        long diff = d2.getTimeInMillis() - d1.getTimeInMillis();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }

    public boolean cadastraProfessor(ArrayList<Professor> professor, Professor p ){
        int k = Main.verificaCadastroP(professor,p.getMatricula());
        if(k == -1){
            professor.add(p);
            return true;
        }else{
            return false;
        }
    }
    public boolean cadastraBibliotecario(ArrayList<Bibliotecario> bibliotecario,Bibliotecario b){
            int k = Main.verificaCadastroB(bibliotecario,b.getMatricula());
            if(k == -1){
                bibliotecario.add(b);
                return true;
           }else{
                return false;
            }
    }

    public String emprestaLivroAluno(ArrayList<Livro> livro, ArrayList<Aluno> aluno, Bibliotecario bibliotecario, ArrayList<Emprestimo> emprestimo,Calendar dataAtual,String matricula, String titulo){
            int k = Main.verificaCadastroA(aluno,matricula);
            if(k != -1){
                    if(aluno.get(k).getSituacao() == 0){
                            int l = Main.verificaCadastroL(livro,titulo);  // Verifica se ha este livro disponivel
                            if(l != -1){
                                    if(livro.get(l).getDisponivel() > 0){
                                            if(aluno.get(k).getLivros_emprestados() < 3){
                                                    livro.get(l).setDisponivel(livro.get(l).getDisponivel() - 1);
                                                    aluno.get(k).setLivros_emprestados(aluno.get(k).getLivros_emprestados() + 1);
                                                    if(aluno.get(k).getNome_livro1() == null){ // Linka o livro ao aluno 
                                                            aluno.get(k).setNome_livro1(titulo);
                                                    }else if(aluno.get(k).getNome_livro2() == null){
                                                            aluno.get(k).setNome_livro2(titulo);

                                                    }else if(aluno.get(k).getNome_livro3() == null){
                                                            aluno.get(k).setNome_livro3(titulo);

                                                    }
                                                    Emprestimo e;
                                                    e = new Emprestimo(bibliotecario.getMatricula(),matricula,livro.get(l).getTitulo(),dataAtual);
                                                    emprestimo.add(e);
                                                    return ("O aluno poderá fica com este livro até dia " + e.getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/" + (e.getDataEntrega().get(Calendar.MONTH)+1) + "/" + e.getDataEntrega().get(Calendar.YEAR));
                                            }else{
                                                    return ("Este aluno já atingiu o limite de livros por aluno");
                                            }

                                    }else{
                                            return("Não há este livro disponível no acervo, todos estão emprestados");
                                    }
                            }else{
                                    return ("Não existe este livro no acervo");
                            }
                    }else{
                         return("Este aluno está com punição de" + aluno.get(k).getSituacao() + "dias");
                    }

            }else{
                    return("Não hã aluno com esta matrícula");
            }
    }


    public String emprestaLivroProfessor(ArrayList<Livro> livro, ArrayList<Professor> professor, Bibliotecario bibliotecario, ArrayList<Emprestimo> emprestimo,Calendar dataAtual,String matricula, String titulo){
            int k = Main.verificaCadastroP(professor,matricula);
            if(k != -1){
                    if(professor.get(k).getSituacao() == 0){
                            int l = Main.verificaCadastroL(livro,titulo);  // Verifica se ha este livro disponivel
                            if(l != -1){
                                    if(livro.get(l).getDisponivel() > 0){
                                            if(professor.get(k).getLivros_emprestados() < 3){
                                                    System.out.println("Livro emprestado com sucesso");
                                                    livro.get(l).setDisponivel(livro.get(l).getDisponivel() - 1);
                                                    professor.get(k).setLivros_emprestados(professor.get(k).getLivros_emprestados() + 1);
                                                    if(professor.get(k).getNome_livro1() == null){ // Linka o livro ao aluno 
                                                            professor.get(k).setNome_livro1(titulo);
                                                    }else if(professor.get(k).getNome_livro2() == null){
                                                            professor.get(k).setNome_livro2(titulo);

                                                    }else if(professor.get(k).getNome_livro3() == null){
                                                            professor.get(k).setNome_livro3(titulo);

                                                    }
                                                    Emprestimo e;
                                                    e = new Emprestimo(bibliotecario.getMatricula(),matricula,livro.get(l).getTitulo(),dataAtual);
                                                    emprestimo.add(e);
                                                    return ("O professor poderá ficar com este livro ate dia " + e.getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/" + (e.getDataEntrega().get(Calendar.MONTH)+1) + "/" + e.getDataEntrega().get(Calendar.YEAR));

                                            }else{
                                                    return ("Este professor já atingiu o limite de livros por professor");
                                            }

                                    }else{
                                            return("Não há este livro disponível no acervo, todos estão emprestados");
                                    }
                            }else{
                                    return("Não existe este livro no acervo");
                            }
                    }else{
                            return("Este professor está proibido de pegar livro por " + professor.get(k).getSituacao() + " dias");
                    }

            }else{
                    return ("Não há professor com esta matricula");
            }
    }

    public String removeLivro(ArrayList<Livro> livro, String titulo){

            if(livro.isEmpty()){
                    return ("Não há livros cadastrados");
            }
            int k = Main.verificaCadastroL(livro,titulo);
            if(k != -1 ){
                    if(livro.get(k).getTotal() == livro.get(k).getDisponivel()){
                        livro.remove(k);
                        return ("O livro foi excluido com sucesso");
                    }else{
                            return ("Este livro não pode ser removido do sistema pois ainda há aluno com ele emprestado, e isso pode trazer inconsitências");
                    }
            }else{
                    return ("Não há livro com este título registrado");

            }
    }




}