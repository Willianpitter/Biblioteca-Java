
import java.io.Serializable;

public class Periodico extends Acervo implements Serializable{

	private double ISSN;
	private int total;
	
	public Periodico(String titulo, String idioma, String area_conhecimento, String ano_publicacao, String autor,
			double iSSN, int total) {
		super(titulo, idioma, area_conhecimento, ano_publicacao, autor);
		ISSN = iSSN;
		this.total = total;
	}

	public double getISSN() {
		return ISSN;
	}

	public void setISSN(double iSSN) {
		ISSN = iSSN;
	}

	public String getTitulo(){
		return titulo;
	}
	
	public void setTitulo(String titulo){
		this.titulo = titulo;
	}
	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return (super.toString() + " ISSN = " + ISSN + "\n" +" total = " + total + "\n");
	}
	
	
}