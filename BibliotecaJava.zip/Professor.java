
import java.io.Serializable;


public class Professor extends Pessoa implements Serializable{
	private String matricula;
	private String departamento;
	private int situacao = 0;
	private int livros_emprestados = 0;
	private String nome_livro1 = null;
	private int ISBN1 = 0;
	private String nome_livro2 = null;
	private int ISBN2 = 0;
	private String nome_livro3 = null;
	private int ISBN3 = 0;
	
	public int getLivros_emprestados() {
		return livros_emprestados;
	}
	public void setLivros_emprestados(int livros_emprestados) {
		this.livros_emprestados = livros_emprestados;
	}
	public String getNome_livro1() {
		return nome_livro1;
	}
	public void setNome_livro1(String nome_livro1) {
		this.nome_livro1 = nome_livro1;
	}
	public int getISBN1() {
		return ISBN1;
	}
	public void setISBN1(int iSBN1) {
		ISBN1 = iSBN1;
	}
	public String getNome_livro2() {
		return nome_livro2;
	}
	public void setNome_livro2(String nome_livro2) {
		this.nome_livro2 = nome_livro2;
	}
	public int getISBN2() {
		return ISBN2;
	}
	public void setISBN2(int iSBN2) {
		ISBN2 = iSBN2;
	}
	public String getNome_livro3() {
		return nome_livro3;
	}
	public void setNome_livro3(String nome_livro3) {
		this.nome_livro3 = nome_livro3;
	}
	public int getISBN3() {
		return ISBN3;
	}
	public void setISBN3(int iSBN3) {
		ISBN3 = iSBN3;
	}

	public Professor(String nome, String cPF, String endereco, String telefone, String email, String matricula,
			String departamento) {
		super(nome, cPF, endereco, telefone, email);
		this.matricula = matricula;
		this.departamento = departamento;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}


	
	public int getSituacao(){
		return situacao;
	}
	
	public void setSituacao(int situacao){
		this.situacao = situacao;
	}
	@Override
	public String toString() {
		return super.toString() + " matricula = " + matricula + "\n" +" departamento = " + departamento + "\n" +" situacao = " + situacao +"\n" + " livros emprestados = "
				+ livros_emprestados + "\n" +" nome do livro 1 = " + nome_livro1 + "\n" +" nome do livro 2 = "
				+ nome_livro2 + "\n"  +" nome do livro 3=" + nome_livro3 +"\n";
	}


}