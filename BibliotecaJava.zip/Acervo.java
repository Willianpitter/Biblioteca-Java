
import java.io.Serializable;


public class Acervo implements Serializable{
	protected String titulo;
	protected String idioma;
	protected String area_conhecimento;
	protected String ano_publicacao;
	protected String autor;
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public String getArea_conhecimento() {
		return area_conhecimento;
	}
	public void setArea_conhecimento(String area_conhecimento) {
		this.area_conhecimento = area_conhecimento;
	}
	public String getAno_publicacao() {
		return ano_publicacao;
	}
	public void setAno_publicacao(String ano_publicacao) {
		this.ano_publicacao = ano_publicacao;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public Acervo(String titulo, String idioma, String area_conhecimento, String ano_publicacao, String autor) {
		super();
		this.titulo = titulo;
		this.idioma = idioma;
		this.area_conhecimento = area_conhecimento;
		this.ano_publicacao = ano_publicacao;
		this.autor = autor;
	}
	@Override
	public String toString() {
		return " título=" + titulo + "\n" +" idioma = " + idioma + "\n" +" área do conhecimento=" + area_conhecimento
				+ "\n" +" ano de publicação = " + ano_publicacao +"\n" + " autor = " + autor + "\n";
	}

	

}