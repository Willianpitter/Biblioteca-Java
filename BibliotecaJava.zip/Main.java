import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Main implements Serializable{
	

	public static Scanner input;
	public static final Calendar data = Calendar.getInstance();
        public static  MenuPrincipal menuprincipal;
        public static ArrayList<Aluno> aluno = new ArrayList<Aluno>(); 
        public static ArrayList<Professor> professor = new ArrayList<Professor>(); 
        public static ArrayList<Bibliotecario> bibliotecario = new ArrayList<Bibliotecario>(); 
	public static ArrayList<Livro> livro = new ArrayList<Livro>(); 
        public static Bibliotecario bibliotecarioLogado;
        public static ArrayList<Emprestimo> emprestimo = new ArrayList<Emprestimo>(); 
        private static ObjectOutputStream output;
        private static ObjectInputStream learquivo;        
;
        public static ArrayList<Periodico> periodico = new ArrayList<Periodico>();
	public static void main(String[] args) throws FileNotFoundException{
            try {
                File name = new File("registroAluno");
                File name2 = new File("registroProfessor");
                File name3 = new File("registroLivro");
                File name4 = new File("registroBibliotecario");
                File name5 = new File("registroPeriodico");
                if(name5.exists() && name5.isFile()){
                    lePeriodico();
                }else{
                  output = new ObjectOutputStream(new FileOutputStream("registroPeriodico"));
                  output.close();
                }
                if(name.exists() && name.isFile()){
                    leAluno();
                }else{
                    output = new ObjectOutputStream(new FileOutputStream("registroAluno"));
                    output.close();
               }
                
               if(name2.exists() && name2.isFile()){
                   leProfessor();
               }else{
                   output = new ObjectOutputStream(new FileOutputStream("registroProfessor"));
                   output.close();
               }
               if(name3.exists() && name3.isFile()){
                   leLivro();
               }else{
                   output = new ObjectOutputStream(new FileOutputStream("registroLivro"));
                   output.close();
               }
               if(name4.exists() && name4.isFile()){
                   leBibliotecario();
               }else{
                   output = new ObjectOutputStream(new FileOutputStream("registroBibliotecario"));
                   output.close();
               }  
               
             
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
              Bibliotecario b = new Bibliotecario("Fulado da Silva","111.111.111-11","Rua fulano","12341234-1234","fulano@hotmail.com","123123","adm","123");
               bibliotecario.add(b);
               menuprincipal = new MenuPrincipal();
               menuprincipal.setVisible(true);
                
}

public static int verificaCadastroA(ArrayList<Aluno> aluno,String matricula){
		for(int i = 0;i < aluno.size();i++){
			if(matricula.equals(aluno.get(i).getMatricula())){
				return i;
			}else if(matricula.equals(aluno.get(i).getCPF())){
                            return i;
                        }   
		}
		return -1;
	
	}

public static int verificaCadastroACPF(ArrayList<Aluno> aluno,String CPF){
		for(int i = 0;i < aluno.size();i++){
			if(CPF.equals(aluno.get(i).getCPF())){
				return i;
			}  
		}
		return -1;
	
	}

public static int verificaCadastroP(ArrayList<Professor> p,String matricula){
	for(int i = 0;i < p.size();i++){
		if(matricula.equals(p.get(i).getMatricula())){
                    return i;
		}else if(matricula.equals(p.get(i).getCPF())){
                    return i;
                }
	}
	return -1;

}

public static int verificaCadastroPCPF(ArrayList<Professor> p,String CPF){
	for(int i = 0;i < p.size();i++){
		if(CPF.equals(p.get(i).getCPF())){
                    return i;
		}
	}
	return -1;

}



public static int verificaCadastroB(ArrayList<Bibliotecario> b,String login,String senha){    
    for(int i = 0;i < b.size();i++){

        if(login.equals(b.get(i).getLogin()) && senha.equals(b.get(i).getSenha())){
			return i;
		}
	}
	return -1;

}

public static int verificaCadastroB(ArrayList<Bibliotecario> b,String matricula){
	for(int i = 0;i < b.size();i++){
		if(matricula.equals(b.get(i).getMatricula())){
			return i;
		}
	}
	return -1;

}

public static void lePeriodico() throws FileNotFoundException, IOException, ClassNotFoundException{
    
    learquivo = new ObjectInputStream(new FileInputStream("registroPeriodico"));
    Periodico p;
    while(true){
   try{
        p = (Periodico)learquivo.readObject();
        periodico.add(p);
   }   catch(IOException | ClassNotFoundException e){
        break;
        }
   }
    learquivo.close();
}


public static void leAluno() throws FileNotFoundException, IOException, ClassNotFoundException{
    
    learquivo = new ObjectInputStream(new FileInputStream("registroAluno"));
    Aluno a;
    while(true){
   try{
        a = (Aluno)learquivo.readObject();
        aluno.add(a);
   }   catch(Exception e){
        break;
        }
   }
    learquivo.close();
}

public static void escreveAluno() throws FileNotFoundException, IOException{
     //output = new Formatter("registroAluno.txt");
    output = new ObjectOutputStream(new FileOutputStream("registroAluno"));
    for(int i = 0; i < aluno.size(); i++){
        output.writeObject(aluno.get(i));
    }
    output.close();

}

public static void escrevePeriodico() throws FileNotFoundException, IOException{
     //output = new Formatter("registroAluno.txt");
    output = new ObjectOutputStream(new FileOutputStream("registroPeriodico"));
    for(int i = 0; i < periodico.size(); i++){
        output.writeObject(periodico.get(i));
    }
    output.close();

}

public static void escreveBibliotecario() throws FileNotFoundException, IOException{

    output = new ObjectOutputStream(new FileOutputStream("registroBibliotecario"));
    for(int i = 0; i < bibliotecario.size(); i++){
        output.writeObject(bibliotecario.get(i));
    }
    output.close();

}

public static void escreveLivro() throws FileNotFoundException, IOException{
     //output = new Formatter("registroAluno.txt");
    output = new ObjectOutputStream(new FileOutputStream("registroLivro"));
    for(int i = 0; i < livro.size(); i++){
        output.writeObject(livro.get(i));
    }
    output.close();

}



public static void escreveProfessor() throws FileNotFoundException, IOException{
     //output = new Formatter("registroAluno.txt");
    output = new ObjectOutputStream(new FileOutputStream("registroProfessor"));
    for(int i = 0; i < professor.size(); i++){
        output.writeObject(professor.get(i));
    }
    output.close();

}

public static void leProfessor() throws FileNotFoundException, IOException, ClassNotFoundException{
    
    learquivo = new ObjectInputStream(new FileInputStream("registroProfessor"));
    Professor p;
    while(true){
        try{
             p = (Professor)learquivo.readObject();
             professor.add(p);
        }   
        catch(Exception e){
             break;
        }
   }
        learquivo.close();
    
}

public static void leLivro() throws FileNotFoundException, IOException, ClassNotFoundException{
    
    learquivo = new ObjectInputStream(new FileInputStream("registroLivro"));
    Livro l;
    while(true){
        try{
             l = (Livro)learquivo.readObject();
             livro.add(l);
        }   
        catch(Exception e){
             break;
        }
   }
        learquivo.close();
    
}


public static void leBibliotecario() throws FileNotFoundException, IOException, ClassNotFoundException{
    
    learquivo = new ObjectInputStream(new FileInputStream("registroBibliotecario"));
    Bibliotecario b;
    while(true){
        try{
             b = (Bibliotecario)learquivo.readObject();
             bibliotecario.add(b);
        }   
        catch(Exception e){
             break;
        }
   }
        learquivo.close();
    
}



public static int verificaCadastroL(ArrayList<Livro> l,String nome){
	for(int i = 0;i < l.size();i++){
		if(nome.equals(l.get(i).getTitulo())){
			return i;
		}
	}
	return -1;
}

public static int verificaCadastroPeriodico(ArrayList<Periodico> p,String nome){
	for(int i = 0;i < p.size();i++){
		if(nome.equals(p.get(i).getTitulo())){
                        System.out.println("Valor de k = " + i);
			return i;
		}
	}
	return -1;
}

public static int verificaCadastroPeriodicoISSN(ArrayList<Periodico> p,Double issn){
	for(int i = 0;i < p.size();i++){
		if(issn == p.get(i).getISSN()){
			return i;
		}
	}
	return -1;
}


public static int verificaCadastroLAutor(ArrayList<Livro> l,String nome){
	for(int i = 0;i < l.size();i++){
		if(nome.equals(l.get(i).getAutor())){
			return i;
		}
	}
	return -1;
}

public static int verificaCadastroL(ArrayList<Livro> l,double isbn){
	for(int i = 0;i < l.size();i++){
		if(isbn == livro.get(i).getISBN()){
			return i;
		}
	}
	return -1;
}

public static void verificaSituacaoProfessor(ArrayList<Professor> professor, ArrayList<Emprestimo> emprestimo){
	String matricula;
	System.out.println("Digite a matrícula do professor que deseja saber a situação na biblioteca");
	matricula = input.nextLine();
	int k = verificaCadastroP(professor,matricula);
	if (k != -1){
		System.out.println("Professor : " + professor.get(k).getNome() + " do departamento " + professor.get(k).getDepartamento());
		if(professor.get(k).getSituacao() == 0){
			
			System.out.println("Este professor não tem nenhuma punição");
		}else{
			System.out.println("Este professor está com punição de " + professor.get(k).getSituacao() + " dias");
		}
		if(professor.get(k).getLivros_emprestados() == 0 ){
			System.out.println("Nenhum livro emprestado");
		}else if(professor.get(k).getLivros_emprestados() == 1){
			System.out.println("Livro emprestado: \n" + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH)+ "/" + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)) ;
			
		}else if(professor.get(k).getLivros_emprestados() == 2 ){
			System.out.println("Livros emprestados: \n" + professor.get(k).getNome_livro1() + "  Data de entrega = " + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) + "/" + (emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)+1)+ "\nData de entrega = " + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) + "/" + (emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro2())).getDataEntrega().get(Calendar.MONTH) +1) );
	
		}if(professor.get(k).getLivros_emprestados() == 3){
			System.out.println("Livros emprestados: \n" + professor.get(k).getNome_livro1() + "  Data de entrega = " + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) + "/" + (emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)+1)+"\n"+ professor.get(k).getNome_livro2() +"\nData de entrega = " + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH)+ "/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro2())).getDataEntrega().get(Calendar.MONTH)+ 1) + "\n"+ professor.get(k).getNome_livro3() + "Data de entrega = " + professor.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,professor.get(k).getNome_livro3())).getDataEntrega().get(Calendar.MONTH)+1 ));
	
		}
	}else{
		System.out.print("Este professor não está registrado no sistema");
	}
}


public static void verificaSituacaoAluno(ArrayList<Aluno> aluno, ArrayList<Emprestimo> emprestimo){
	String matricula;
	System.out.println("Digite a matrícula do aluno que deseja saber a situação na biblioteca");
	matricula = input.nextLine();
	int k = verificaCadastroA(aluno,matricula);
	if (k != -1){
		System.out.println("Aluno : " + aluno.get(k).getNome() + " do curso " + aluno.get(k).getCurso());
		if(aluno.get(k).getSituacao() == 0){
			
			System.out.println("Este aluno tem nenhuma punição");
		}else{
			System.out.println("Este aluno está com punição de " + aluno.get(k).getSituacao() + " dias");
		}
		if(aluno.get(k).getLivros_emprestados() == 0 ){
			System.out.println("Nenhum livro emprestado");
		}else if(aluno.get(k).getLivros_emprestados() == 1){
			System.out.println("Livro emprestado: \n" + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)+1)) ;
			
		}else if(aluno.get(k).getLivros_emprestados() == 2 ){
			System.out.println("Livros emprestados: \n" + aluno.get(k).getNome_livro1() + "  Data de entrega = " + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH)+ "/" + (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)+1)+ "\nData de entrega = " + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro2())).getDataEntrega().get(Calendar.MONTH)+1)  );
	
		}if(aluno.get(k).getLivros_emprestados() == 3){
			System.out.println("Livros emprestados: \n" + aluno.get(k).getNome_livro1() + "  Data de entrega = " + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) + "/" + (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.MONTH)+1) + "\n"+ aluno.get(k).getNome_livro2() +"\nData de entrega = " + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH)+ "/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro2())).getDataEntrega().get(Calendar.MONTH)+1)+ "\n"+ aluno.get(k).getNome_livro3() + "Data de entrega = " + aluno.get(k).getNome_livro1() + "  Data de entrega = " + emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro1())).getDataEntrega().get(Calendar.DAY_OF_MONTH) +"/"+ (emprestimo.get(verificaEmprestimo(emprestimo,matricula,aluno.get(k).getNome_livro3())).getDataEntrega().get(Calendar.MONTH)+1) );
	
		}
	}else{
		System.out.print("Este aluno não está registrado no sistema");
	}
}

public static int verificaEmprestimo(ArrayList<Emprestimo> emprestimo,String matricula, String titulo ){
	for(int i = 0; i < emprestimo.size(); i++){
		if(matricula.equals(emprestimo.get(i).getMatricula()) && titulo.equals(emprestimo.get(i).getTitulo())){
			return i;
		}
	}
	return -1;

}


public static Calendar getData() {
	return data;
}

public static void setData(Calendar data,ArrayList<Aluno> aluno,ArrayList<Professor> professor) {
	data.add(Calendar.DAY_OF_MONTH,1);
	for(int i = 0; i < aluno.size(); i++){
		if(aluno.get(i).getSituacao() != 0){	// Diminiu um dia na punicao
			aluno.get(i).setSituacao(aluno.get(i).getSituacao() - 1);
		}
	}
	for(int i = 0; i < professor.size(); i++){  // Diminiu um dia na punicao
		if(professor.get(i).getSituacao() != 0){
			professor.get(i).setSituacao(professor.get(i).getSituacao() - 1);
		}
	}
	
}

public static void verTodosLivros(ArrayList<Livro> livros){
	for(Livro l : livros){
		System.out.println(l.getTitulo() + "\n\n");
	}
}





}
