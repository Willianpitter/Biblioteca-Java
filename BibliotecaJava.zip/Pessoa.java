
import java.io.Serializable;


public class Pessoa implements Serializable{
		protected String nome;
		protected String CPF;
		protected String endereco;
		protected String telefone;
		protected String email;
		//protected data_nasc;

		public Pessoa(String nome, String cPF, String endereco, String telefone, String email) {
			super();
			this.nome = nome;
			CPF = cPF;
			this.endereco = endereco;
			this.telefone = telefone;
			this.email = email;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getCPF() {
			return CPF;
		}

		public void setCPF(String cPF) {
			CPF = cPF;
		}

		public String getEndereco() {
			return endereco;
		}

		public void setEndereco(String endereco) {
			this.endereco = endereco;
		}

		public String getTelefone() {
			return telefone;
		}

		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@Override
		public String toString() {
			return " nome = " + nome +"\n" + " CPF = " + CPF + "\n" +" endereco = " + endereco + "\n" +" telefone = " + telefone
					+"\n" + " email = " + email + "\n";
		}
                
                public String toStringArquivo() {
			return nome +"\n" + CPF + "\n"  + endereco + "\n"+ telefone
					+"\n" + email + "\n";
		}
	
}